﻿----------------------------------------------------------------------------
----Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------

blackHUD = {};
local settingsFile = loadXMLFile("modDesc", g_currentModDirectory .. "modDesc.xml");
blackHUD.title = getXMLString(settingsFile, "modDesc.title.en");
blackHUD.author = getXMLString(settingsFile, "modDesc.author");
blackHUD.version = getXMLString(settingsFile, "modDesc.version");
-------------------------------------------------------
local bgY = 0.0093;
local ratioDiv = 11/7;
local fullAlpha = 1.0;
settingsFile = loadXMLFile("hudConfig", g_currentModDirectory .. "hudConfig.xml");
local orangeBottom = Utils.getNoNil(getXMLBool(settingsFile, "hudConfig.bg.showBottomStrip"), true);
if orangeBottom then blackHUD.backgroundOL = createImageOverlay(g_currentModDirectory.."back.dds");
blackHUD.bgOLPath = g_currentModDirectory.."back.dds";
else blackHUD.backgroundOL = createImageOverlay(g_currentModDirectory.."black.dds"); bgY = 0.0091; fullAlpha = 0.5 end;
blackHUD.boldText = false;
blackHUD.postLoad = false;
blackHUD.wide = false;
-------------------------------------------------------
blackHUD.alpha = Utils.getNoNil(getXMLFloat(settingsFile, "hudColor.alpha"), 0.9);
blackHUD.color = {0.0, 0.0, 0.0, blackHUD.alpha};
blackHUD.color2 = {0.02, 0.02, 0.02, blackHUD.alpha}; --Clock's small hand color
-------------------------------------------------------
local gameSettingsFile = loadXMLFile("gameSettings", getUserProfileAppPath() .. "gameSettings.xml");
local giScale = Utils.getNoNil(getXMLFloat(gameSettingsFile, "gameSettings.uiScale"), 1.0);
--print(SettingsModel:getValue(SettingsModel.SETTING.UI_SCALE, true));
--print(SettingsModel.SETTING.UI_SCALE);
delete(gameSettingsFile);
blackHUD.OLW = (0.138 * 2) * giScale;
local widthAdjust = getXMLFloat(settingsFile, "hudConfig.bg.bgWidth");
if widthAdjust ~= nil and widthAdjust ~= 1.0 then 
	if widthAdjust > 0.5 and widthAdjust < 2.0 then
		blackHUD.OLW = blackHUD.OLW * widthAdjust;
	end;
end;
local marginX = 0.1-((giScale-0.5)/10);
blackHUD.OLWS = blackHUD.OLW * (0.8 + marginX);
blackHUD.OLH = ((0.028 * 2) * giScale) * ratioDiv;
blackHUD.OLX = 1.0 - (blackHUD.OLW + 0.004);
blackHUD.OLXS = 1.0 - (blackHUD.OLWS + 0.004);
bgY = (bgY / (giScale*2)) * ratioDiv;
blackHUD.OLY = 1.0 - (blackHUD.OLH + bgY);
bgY = nil;
giScale = nil;
ratioDiv = nil;
marginX = nil;
-------------------------------------------------------
--[[blackHUD.daycolor = {0.0, 0.0, 0.0, blackHUD.alpha};
blackHUD.daycolor2 = {0.02, 0.02, 0.02, blackHUD.alpha};
blackHUD.nightcolor = {1.0, 1.0, 1.0, blackHUD.alpha};
blackHUD.nightcolor2 = {0.85, 0.85, 0.85, blackHUD.alpha};]]
-------------------------------------------------------
local red = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.blackColor.red#value"), 0.0);
local green = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.blackColor.green#value"), 0.0);
local blue = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.blackColor.blue#value"), 0.0);
if red > 1.0 then red = 1; end;
if red < 0.01 then red = 0.01; end;
if green > 1.0 then green = 1; end;
if green < 0.01 then green = 0.01; end;
if blue > 1.0 then blue = 1; end;
if blue < 0.01 then blue = 0.01; end;
blackHUD.daycolor = {red, green, blue, blackHUD.alpha};
red = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.blackColor2.red#value"), 0.1);
green = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.blackColor2.green#value"), 0.1);
blue = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.blackColor2.blue#value"), 0.1);
if red > 1.0 then red = 1; end;
if red < 0.01 then red = 0.01; end;
if green > 1.0 then green = 1; end;
if green < 0.01 then green = 0.01; end;
if blue > 1.0 then blue = 1; end;
if blue < 0.01 then blue = 0.01; end;
blackHUD.daycolor2 = {red, green, blue, blackHUD.alpha};
red = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.whiteColor.red#value"), 1.0);
green = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.whiteColor.green#value"), 1.0);
blue = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.whiteColor.blue#value"), 1.0);
if red > 1.0 then red = 1; end;
if red < 0.01 then red = 0.01; end;
if green > 1.0 then green = 1; end;
if green < 0.01 then green = 0.01; end;
if blue > 1.0 then blue = 1; end;
if blue < 0.01 then blue = 0.01; end;
blackHUD.nightcolor = {red, green, blue, blackHUD.alpha};
red = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.whiteColor2.red#value"), 0.45);
green = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.whiteColor2.green#value"), 0.45);
blue = Utils.getNoNil(getXMLFloat(settingsFile, "hudConfig.whiteColor2.blue#value"), 0.45);
if red > 1.0 then red = 1; end;
if red < 0.01 then red = 0.01; end;
if green > 1.0 then green = 1; end;
if green < 0.01 then green = 0.01; end;
if blue > 1.0 then blue = 1; end;
if blue < 0.01 then blue = 0.01; end;
blackHUD.nightcolor2 = {red, green, blue, blackHUD.alpha};
-------------------------------------------------------
setOverlayColor(blackHUD.backgroundOL, 1.0, 1.0, 1.0, fullAlpha); --full color w/embeded alpha
-------------------------------------------------------
red = nil;
green = nil;
blue = nil;
fullAlpha = nil;
-------------------------------------------------------
blackHUD.isActive = true;
blackHUD.isBGActive = false;
blackHUD.useBG = Utils.getNoNil(getXMLBool(settingsFile, "hudConfig.bg.useBGinstead"), false);
if blackHUD.useBG then
	blackHUD.isActive = false;
	blackHUD.isBGActive = true;
	blackHUD.color = {blackHUD.nightcolor[1], blackHUD.nightcolor[2], blackHUD.nightcolor[3], blackHUD.alpha};
	blackHUD.color2 = {blackHUD.nightcolor2[1], blackHUD.nightcolor2[2], blackHUD.nightcolor2[3], blackHUD.alpha};
end;
delete(settingsFile);
print("Load mod: "..blackHUD.title.." : v"..blackHUD.version.." by "..blackHUD.author);
-------------------------------------------------------


function blackHUD:loadMap(dt)
	GameInfoDisplay.update = Utils.prependedFunction(blackHUD.updateGameInfo, GameInfoDisplay.update);
end;

function blackHUD:updateGameInfo()
	if blackHUD.postLoad then
		if blackHUD.isBGActive and g_currentMission.hud.isVisible then
			if not g_gui:getIsGuiVisible() then
				if blackHUD.wide then
					local w = blackHUD.OLW;
					local x = blackHUD.OLX;
					if #g_currentMission.weatherIcons > 1 then
						w = w * 1.1;
						x = 1.0 - (w + 0.004);
					end;
					renderOverlay(blackHUD.backgroundOL, x, blackHUD.OLY, w, blackHUD.OLH);
				else
					renderOverlay(blackHUD.backgroundOL, blackHUD.OLXS, blackHUD.OLY, blackHUD.OLWS, blackHUD.OLH);
				end;
			end;
		end;
    end;
end;

function blackHUD:updateIconColors(g_currentMission)

	if g_currentMission.moneyIcon ~= nil then
		g_currentMission.moneyIcon:setColor(unpack(blackHUD.color));
	end;

	if g_currentMission.clockIcon ~= nil then
		g_currentMission.clockIcon:setColor(unpack(blackHUD.color));
	end;
	if g_currentMission.clockSHIcon ~= nil then
		g_currentMission.clockSHIcon:setColor(unpack(blackHUD.color));
	end;
	if g_currentMission.clockLHIcon ~= nil then
		g_currentMission.clockLHIcon:setColor(unpack(blackHUD.color));
	end;

	if g_currentMission.timeScaleIcons ~= nil and #g_currentMission.timeScaleIcons > 0 then
		for _, icon in pairs (g_currentMission.timeScaleIcons) do
			if icon.r ~= blackHUD.color[1] then
				icon:setColor(unpack(blackHUD.color));
			end;
		end;
	end;

	if g_currentMission.verticalSeparators ~= nil and #g_currentMission.verticalSeparators > 0 then
		for _, entry in pairs(g_currentMission.verticalSeparators) do
			if icon.r ~= blackHUD.color[1] then
				icon:setColor(unpack(blackHUD.color));
			end;
		end;
	end;

end;

function blackHUD:update(dt)

	local dayMinutes = g_currentMission.environment.dayTime/(1000*60);
	local nightTime = (dayMinutes > g_currentMission.environment.nightStartMinutes or dayMinutes < (g_currentMission.environment.nightEndMinutes-30));

	if blackHUD.isActive then
		if nightTime then
			if blackHUD.color[1] ~= blackHUD.nightcolor[1] then
				blackHUD.color = {blackHUD.nightcolor[1], blackHUD.nightcolor[2], blackHUD.nightcolor[3], blackHUD.nightcolor[4]};
				blackHUD.color2 = {blackHUD.nightcolor2[1], blackHUD.nightcolor2[2], blackHUD.nightcolor2[3], blackHUD.nightcolor2[4]};
				blackHUD:updateIconColors(g_currentMission);
				blackHUD.boldText = false;
			end;
		else
			if blackHUD.color[1] ~= blackHUD.daycolor[1] then
				blackHUD.color = {blackHUD.daycolor[1], blackHUD.daycolor[2], blackHUD.daycolor[3], blackHUD.daycolor[4]};
				blackHUD.color2 = {blackHUD.daycolor2[1], blackHUD.daycolor2[2], blackHUD.daycolor2[3], blackHUD.daycolor2[4]};
				blackHUD:updateIconColors(g_currentMission);
				blackHUD.boldText = true;
			end;
		end;
		
		if g_currentMission.weatherIcons ~= nil and #g_currentMission.weatherIcons > 0 then
			for _, icon in pairs (g_currentMission.weatherIcons) do
				if icon.r ~= blackHUD.color[1] then
					icon:setColor(unpack(blackHUD.color));
				end;
			end;
			if not blackHUD.wide then
				blackHUD.wide = true;
			end;
		else
			if blackHUD.wide then
				blackHUD.wide = false;
			end;
		end;
    end;
	if blackHUD.useBG then
		if nightTime and blackHUD.isBGActive then
			blackHUD.isBGActive = false;
		elseif not nightTime and not blackHUD.isBGActive then
			blackHUD.isBGActive = true;
		end;
    end;

end;

--[[if blackHUD.useBG then
	GameInfoDisplay.createBackground = function(self)
		local posX, posY = GameInfoDisplay.getBackgroundPosition(1.2); -- top right corner
		local width, height = unpack(GameInfoDisplay.SIZE.SELF);
		GameInfoDisplay.SIZE.SELF = {width*1.1, height*1.2};
		local x, y =  unpack(GameInfoDisplay.POSITION.SELF);
		GameInfoDisplay.POSITION.SELF = {x-((width*1.1) -width), y-((height*1.1)-height)};
		width, height = getNormalizedScreenValues(unpack(GameInfoDisplay.SIZE.SELF));
		return Overlay:new(blackHUD.bgOLPath, posX - width, posY - height, width, height);
	end;
end;]]

GameInfoDisplay.drawMoneyText = function(self)

    setTextBold(blackHUD.boldText);
    setTextAlignment(RenderText.ALIGN_RIGHT);
    setTextColor(unpack(blackHUD.color));
    if g_currentMission.player ~= nil then
        local farm = g_farmManager:getFarmById(g_currentMission.player.farmId);
        local moneyText = g_i18n:formatMoney(farm.money, 0, false, true);
		blackHUD.postLoad = true;
        renderText(self.moneyTextPositionX, self.moneyTextPositionY, self.moneyTextSize, moneyText);	
    end;
	

end;

GameInfoDisplay.drawTimeText = function(self)

    setTextBold(blackHUD.boldText);
    setTextAlignment(RenderText.ALIGN_RIGHT);
    setTextColor(unpack(blackHUD.color));
    renderText(self.timeTextPositionX, self.timeTextPositionY, self.timeTextSize, self.timeText);
    renderText(self.timeScaleTextPositionX, self.timeScaleTextPositionY, self.timeScaleTextSize, self.timeScaleText);

end;

GameInfoDisplay.drawTemperatureText = function(self)

    setTextBold(blackHUD.boldText);
    setTextAlignment(RenderText.ALIGN_RIGHT);
    setTextColor(unpack(blackHUD.color));
    renderText(self.temperatureHighTextPositionX, self.temperatureHighTextPositionY, self.temperatureTextSize, self.temperatureDayText);
    renderText(self.temperatureLowTextPositionX, self.temperatureLowTextPositionY, self.temperatureTextSize, self.temperatureNightText);

end;

GameInfoDisplay.addActiveWeatherAnimation = function(self, animationSequence, isCurrentWeatherIcon, icon)

    local transparentColor = {blackHUD.color[1], blackHUD.color[2], blackHUD.color[3], 0};
    local fadeInSequence = TweenSequence.new(icon);
    local fadeIn = MultiValueTween:new(icon.setColor, transparentColor, blackHUD.color, HUDDisplayElement.MOVE_ANIMATION_DURATION);
    fadeInSequence:insertTween(fadeIn, 0);
    fadeInSequence:insertCallback(icon.setVisible, true, 0);
    fadeInSequence:start();
    animationSequence:insertTween(fadeInSequence, 0);

	if g_currentMission.weatherIcons ~= nil and #g_currentMission.weatherIcons > 0 then
		for i, entry in pairs(g_currentMission.weatherIcons) do
			if icon ~= entry and i >= #g_currentMission.weatherIcons then
				table.insert(g_currentMission.weatherIcons, icon);
			end;
		end;
	end;

end;

GameInfoDisplay.addInactiveWeatherAnimation = function(self, animationSequence, icon)

    local transparentColor = {blackHUD.color[1], blackHUD.color[2], blackHUD.color[3], 0};
    local fadeOutSequence = TweenSequence.new(icon);
    local fadeOut = MultiValueTween:new(icon.setColor, blackHUD.color, transparentColor, HUDDisplayElement.MOVE_ANIMATION_DURATION);
    fadeOutSequence:insertTween(fadeOut, 0);
    fadeOutSequence:addCallback(icon.setVisible, false);
    fadeOutSequence:start();
    animationSequence:insertTween(fadeOutSequence, 0);
	
	if g_currentMission.weatherIcons ~= nil and #g_currentMission.weatherIcons > 0 then
		for i, entry in pairs(g_currentMission.weatherIcons) do
			if icon ~= entry and i >= #g_currentMission.weatherIcons then
				table.insert(g_currentMission.weatherIcons, icon);
			end;
		end;
	end;

end;

GameInfoDisplay.createMoneyBox = function(self, hudAtlasPath, rightX, bottomY)

    local iconWidth, iconHeight = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.MONEY_ICON);
    local boxWidth, boxHeight = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.MONEY_BOX);
    local posX = rightX - boxWidth;
    local posY = bottomY + (boxHeight - iconHeight) * 0.5;
    local boxOverlay = Overlay:new(nil, posX, bottomY, boxWidth, boxHeight);
    local boxElement = HUDElement:new(boxOverlay);
    self.moneyBox = boxElement;
    self:addChild(boxElement);
    table.insert(self.infoBoxes, self.moneyBox);
    local iconOverlay = Overlay:new(hudAtlasPath, posX, posY, iconWidth, iconHeight);
    iconOverlay:setUVs(getNormalizedUVs(GameInfoDisplay.UV.MONEY_ICON[self.moneyUnit]));
    iconOverlay:setColor(unpack(blackHUD.color));
    self.moneyIconOverlay = iconOverlay;
    boxElement:addChild(HUDElement:new(iconOverlay));

	g_currentMission.moneyIcon = iconOverlay;

    return posX;

end;

GameInfoDisplay.createTimeBox = function(self, hudAtlasPath, rightX, bottomY)

    local boxWidth, boxHeight = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.TIME_BOX);
    local posX = rightX - boxWidth;
    local boxOverlay = Overlay:new(nil, posX, bottomY, boxWidth, boxHeight);
    local boxElement = HUDElement:new(boxOverlay);
    self.timeBox = boxElement;
    self:addChild(boxElement);
    table.insert(self.infoBoxes, self.timeBox);
    local clockWidth, clockHeight = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.TIME_ICON);
    local posY = bottomY + (boxHeight - clockHeight) * 0.5;
    local clockOverlay = Overlay:new(hudAtlasPath, posX, posY, clockWidth, clockHeight);
    clockOverlay:setUVs(getNormalizedUVs(GameInfoDisplay.UV.TIME_ICON));
    clockOverlay:setColor(unpack(blackHUD.color));
    local clockElement = HUDElement:new(clockOverlay);
    self.clockElement = clockElement;
    boxElement:addChild(clockElement);
    posX, posY = posX + clockWidth * 0.5, posY + clockHeight * 0.5;
    self.clockHandSmall = self:createClockHand(hudAtlasPath, posX, posY,
        GameInfoDisplay.SIZE.CLOCK_HAND_SMALL,
        GameInfoDisplay.UV.CLOCK_HAND_SMALL,
        blackHUD.color,
        GameInfoDisplay.PIVOT.CLOCK_HAND_SMALL);
    clockElement:addChild(self.clockHandSmall);
    self.clockHandLarge = self:createClockHand(hudAtlasPath, posX, posY,
        GameInfoDisplay.SIZE.CLOCK_HAND_LARGE,
        GameInfoDisplay.UV.CLOCK_HAND_LARGE,
        blackHUD.color2,
        GameInfoDisplay.PIVOT.CLOCK_HAND_LARGE);
    clockElement:addChild(self.clockHandLarge);
    local arrowOffX, arrowOffY = self:scalePixelToScreenVector(GameInfoDisplay.POSITION.TIME_SCALE_ARROW)
    posX, posY = rightX + arrowOffX, bottomY + arrowOffY;
    self.timeScaleArrow = self:createTimeScaleArrow(hudAtlasPath, posX, posY,
        GameInfoDisplay.SIZE.TIME_SCALE_ARROW,
        GameInfoDisplay.UV.TIME_SCALE_ARROW);
    boxElement:addChild(self.timeScaleArrow);
    self.timeScaleArrowFast = self:createTimeScaleArrow(hudAtlasPath, posX, posY,
        GameInfoDisplay.SIZE.TIME_SCALE_ARROW_FAST,
        GameInfoDisplay.UV.TIME_SCALE_ARROW_FAST);
    boxElement:addChild(self.timeScaleArrowFast);

	g_currentMission.clockIcon = clockOverlay;
	g_currentMission.clockSHIcon = self.clockHandSmall;
	g_currentMission.clockLHIcon = self.clockHandLarge;

    return rightX - boxWidth;

end;

GameInfoDisplay.createTemperatureBox = function(self, hudAtlasPath, rightX, bottomY)

    local boxWidth, boxHeight = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.TEMPERATURE_BOX);
    local posX = rightX - boxWidth;
    local boxOverlay = Overlay:new(nil, posX, bottomY, boxWidth, boxHeight);
    local boxElement = HUDElement:new(boxOverlay);
    self.temperatureBox = boxElement;
    self:addChild(boxElement);
    table.insert(self.infoBoxes, self.temperatureBox);
    self.temperatureIconStable = self:createTemperatureIcon(hudAtlasPath, posX, bottomY, boxHeight,
        GameInfoDisplay.UV.TEMPERATURE_ICON_STABLE, blackHUD.color);
    boxElement:addChild(self.temperatureIconStable);
    self.temperatureIconRising = self:createTemperatureIcon(hudAtlasPath, posX, bottomY, boxHeight,
        GameInfoDisplay.UV.TEMPERATURE_ICON_RISING, blackHUD.color);
    boxElement:addChild(self.temperatureIconRising);
    self.temperatureIconDropping = self:createTemperatureIcon(hudAtlasPath, posX, bottomY, boxHeight,
        GameInfoDisplay.UV.TEMPERATURE_ICON_DROPPING, blackHUD.color);
    boxElement:addChild(self.temperatureIconDropping);

	g_currentMission.tempOverlay = boxOverlay;

    return rightX - boxWidth;

end;

GameInfoDisplay.createWeatherBox = function(self, hudAtlasPath, rightX, bottomY)
    local boxWidth, boxHeight = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.WEATHER_BOX);
    local posX = rightX - boxWidth;
    local boxOverlay = Overlay:new(nil, posX, bottomY, boxWidth, boxHeight);
    boxOverlay:setColor(unpack(blackHUD.color));
    local boxElement = HUDElement:new(boxOverlay);
    self.weatherBox = boxElement;
    self:addChild(boxElement);
    table.insert(self.infoBoxes, self.weatherBox);
    local weatherUvs = self:getWeatherUVs();

    for weatherId, uvs in pairs(weatherUvs) do
        local weatherIcon = self:createWeatherIcon(hudAtlasPath, weatherId, boxHeight, uvs, blackHUD.color);
        boxElement:addChild(weatherIcon);
        self.weatherTypeIcons[weatherId] = weatherIcon;
		for _, entry in pairs(self.weatherTypeIcons) do
			if g_currentMission.weatherIcons ~= nil and #g_currentMission.weatherIcons > 0 then
				for ii, entry2 in pairs(g_currentMission.weatherIcons) do
					if entry2 ~= entry and ii >= #g_currentMission.weatherIcons then
						table.insert(g_currentMission.weatherIcons, entry);
					end;
				end;
			else
				g_currentMission.weatherIcons = {};
				table.insert(g_currentMission.weatherIcons, entry);
			end;
		end;
    end;

	g_currentMission.weatherOverlay = boxOverlay;

    return rightX - boxWidth;
end;

GameInfoDisplay.createTimeScaleArrow = function(self, hudAtlasPath, posX, posY, size, uvs)

    local arrowWidth, arrowHeight = self:scalePixelToScreenVector(size);
    local arrowOverlay = Overlay:new(hudAtlasPath, posX, posY, arrowWidth, arrowHeight);
    arrowOverlay:setUVs(getNormalizedUVs(uvs));
    arrowOverlay:setColor(unpack(blackHUD.color));
		
	if g_currentMission.timeScaleIcons ~= nil and #g_currentMission.timeScaleIcons > 0 then
		for i, entry in pairs(g_currentMission.timeScaleIcons) do
			if entry ~= arrowOverlay and i >= #g_currentMission.timeScaleIcons then
				table.insert(g_currentMission.timeScaleIcons, arrowOverlay);
			end;
		end;
	else
		g_currentMission.timeScaleIcons = {};
		table.insert(g_currentMission.timeScaleIcons, arrowOverlay);
	end;

    return HUDElement:new(arrowOverlay);

end;

GameInfoDisplay.createWeatherIcon = function(self, hudAtlasPath, weatherId, boxHeight, uvs, color)

    local width, height = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.WEATHER_ICON);
    local overlay = Overlay:new(hudAtlasPath, 0, 0, width, height); -- position is set on update
    overlay:setUVs(getNormalizedUVs(uvs));
	overlay:setColor(unpack(blackHUD.color));
    local element = HUDElement:new(overlay);
    element:setVisible(false);
	g_currentMission.weatherIcon2 = overlay;

    return element;

end;

GameInfoDisplay.addBecomeCurrentWeatherAnimation = function(self, animationSequence, icon)

    local currentColor = {icon:getColor()};
    local makeCurrent = MultiValueTween:new(icon.setColor, currentColor, blackHUD.color, HUDDisplayElement.MOVE_ANIMATION_DURATION);
    makeCurrent:setTarget(icon);
    animationSequence:insertTween(makeCurrent, 0);

	g_currentMission.weatherIcon = icon;

end;

GameInfoDisplay.createVerticalSeparator = function(self, hudAtlasPath, posX, centerPosY)
    local width, height = self:scalePixelToScreenVector(GameInfoDisplay.SIZE.SEPARATOR);
    width = math.max(width, 1 / g_screenWidth);
    local overlay = Overlay:new(hudAtlasPath, posX - width * 0.5, centerPosY - height * 0.5, width, height);
    overlay:setUVs(getNormalizedUVs(GameInfoDisplay.UV.SEPARATOR));
    overlay:setColor(unpack(blackHUD.color));

	if g_currentMission.verticalSeparators ~= nil and #g_currentMission.verticalSeparators > 0 then
		for i, entry in pairs(g_currentMission.verticalSeparators) do
			if icon ~= entry and i >= #g_currentMission.verticalSeparators then
				table.insert(g_currentMission.verticalSeparators, overlay);
			end;
		end;
	end;

    return HUDElement:new(overlay);	

end;

addModEventListener(blackHUD);
