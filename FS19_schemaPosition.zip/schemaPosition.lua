﻿----------------------------------------------------------------------------
----Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------
schemaPosition = {};
schemaPosition.dir = g_currentModDirectory;
local modDescFile = loadXMLFile("modDesc", schemaPosition.dir .. "modDesc.xml");
schemaPosition.title = getXMLString(modDescFile, "modDesc.title.en");
schemaPosition.author = getXMLString(modDescFile, "modDesc.author");
schemaPosition.version = getXMLString(modDescFile, "modDesc.version");
schemaPosition.loadOnly = getXMLBool(modDescFile, "modDesc.loadOnly");
delete(modDescFile);
schemaPosition.width = 0;
schemaPosition.position = 2;

function schemaPosition:loadMap(savegame)
	FSBaseMission.saveSavegame = Utils.appendedFunction(FSBaseMission.saveSavegame, schemaPosition.saveSettings);
	local savegameFolderPath = g_currentMission.missionInfo.savegameDirectory;
	if savegameFolderPath == nil then
		savegameFolderPath = ('%ssavegame%d'):format(getUserProfileAppPath(), g_currentMission.missionInfo.savegameIndex);
	end;
	if fileExists(savegameFolderPath.."/schemaPosition.xml") then 
		local positionFile = loadXMLFile("schemaPosition", savegameFolderPath.."/schemaPosition.xml");
		schemaPosition.position = Utils.getNoNil(getXMLInt(positionFile, "schemaPosition#position"),schemaPosition.position);
	end;
	print("Load mod: "..schemaPosition.title.." : v"..schemaPosition.version.." by "..schemaPosition.author.." Position: "..schemaPosition.position);
	if schemaPosition.loadOnly then removeModEventListener(schemaPosition); end;
end;

function schemaPosition:relocateVehicleSchema(posX, posY)
-- always used scaled values based upon the originals, never direct numbers.
	local width = schemaPosition.width/2;
	if schemaPosition.position == 1 then --top right
		posX = 1-posX;
		posX = posX-(posX*0.0065)-width;
		posY = posY-(posY*0.045);
	elseif schemaPosition.position == 2 then -- bottom right
		posX = 1-posX;
		posY = 1-posY;
		posX = posX-(posX*0.0296)-width;
		posY = posY-(posY*0.84);
	elseif schemaPosition.position == 3 then -- bottom left
		posY = 1-posY;
		posX = posX+(posX*0.5)-width;
		posY = posY-(posY*0.864);
	end;

	return posX, posY;
end;

VehicleSchemaDisplay.getBackgroundPosition = function(isDocked, uiScale)

    local width, height = getNormalizedScreenValues(unpack(VehicleSchemaDisplay.SIZE.SELF));
    local posX, posY = g_safeFrameOffsetX, 1 - g_safeFrameOffsetY - height * uiScale; -- top left anchored
	if schemaPosition.position ~= 0 then
		posX, posY = schemaPosition:relocateVehicleSchema(posX, posY);
	else    
		if isDocked then
			local offX, offY = getNormalizedScreenValues(unpack(VehicleSchemaDisplay.POSITION.SELF_DOCKED));
			posX = posX + (offX - width) * uiScale;
			posY = posY + offY * uiScale;
		end;
	end;

    return posX, posY;
end;

VehicleSchemaDisplay.setDocked = function(self, isDocked, animate)
	if schemaPosition.position ~= 0 then isDocked = false; end; -- prevent docking offset
	local targetX, targetY = VehicleSchemaDisplay.getBackgroundPosition(isDocked, self:getScale());
	if animate and self.animation:getFinished() then
		local startX, startY = self:getPosition();
		self:animateDocking(startX, startY, targetX, targetY, isDocked);
	else
		self.animation:stop();
		self.isDocked = isDocked;
		self:setPosition(targetX, targetY);
	end;
end;

VehicleSchemaDisplay.drawVehicleSchemaOverlays = function(self, vehicle)
    vehicle = vehicle:getRootVehicle();
    if vehicle.schemaOverlay ~= nil then
        local overlays, overlayHeight = self:getVehicleSchemaOverlays(vehicle);
        local baseX, baseY = self:getPosition();
        baseY = baseY + (self:getHeight()-overlayHeight)*0.5;
        if self.isDocked then baseX = baseX + self:getWidth(); end;
        local minX, maxX = self:getSchemaDelimiters(overlays);      
        local scale = 1;
        local sizeX = maxX - minX;
		if schemaPosition.position ~= 0 then
			if schemaPosition.width ~= sizeX then 
				schemaPosition.width = sizeX;
				self:setDocked(false, false);
				return;
			end;
		end;
        if sizeX > self.maxSchemaWidth then scale = self.maxSchemaWidth / sizeX; end;
        local newPosX = baseX;
        if self.isDocked then
            newPosX = newPosX - maxX * scale;
        else
            newPosX = newPosX - minX * scale;
        end;
        for _, overlayDesc in pairs(overlays) do
            local overlay = overlayDesc.overlay;
            local width, height = overlay.width, overlay.height;
            overlay:setInvertX(overlayDesc.invertX);
            overlay:setPosition(newPosX + overlayDesc.x, baseY + overlayDesc.y);
            overlay:setRotation(overlayDesc.rotation, 0, 0);
            overlay:setDimension(width * scale, height * scale);
            overlay:render();
            if overlayDesc.additionalText ~= nil then
                local posX = newPosX + overlayDesc.x + (width * scale) * 0.5;
                local posY = baseY + overlayDesc.y + (height * scale);
                setTextBold(false);
                setTextColor(1, 1, 1, 1);
                setTextAlignment(RenderText.ALIGN_CENTER);
                renderText(posX, posY, getCorrectTextSize(0.009), overlayDesc.additionalText);
                setTextAlignment(RenderText.ALIGN_LEFT);
                setTextColor(1, 1, 1, 1);
            end;
            overlay:setDimension(width, height);
        end;
    end;
end;

function schemaPosition:saveSettings()
	local savegameFolderPath = g_currentMission.missionInfo.savegameDirectory.."/";
	if savegameFolderPath == nil then
		savegameFolderPath = ('%ssavegame%d'):format(getUserProfileAppPath(), g_currentMission.missionInfo.savegameIndex.."/");
	end;
	local positionFile = createXMLFile("schemaPosition", savegameFolderPath.."schemaPosition.xml", "schemaPosition");
	setXMLInt(positionFile, "schemaPosition#position",schemaPosition.position);
	saveXMLFile(positionFile);
	delete(positionFile);
end;

function schemaPosition:update(dt)
	if Input.isKeyPressed(Input.KEY_rctrl) then
		if Input.isKeyPressed(Input.KEY_KP_0) then
			schemaPosition.position = 0;
		elseif Input.isKeyPressed(Input.KEY_KP_1) then
			schemaPosition.position = 1;
		elseif Input.isKeyPressed(Input.KEY_KP_2) then
			schemaPosition.position = 2;
		elseif Input.isKeyPressed(Input.KEY_KP_3) then
			schemaPosition.position = 3;
		elseif Input.isKeyPressed(Input.KEY_rshift) then
			if Input.isKeyPressed(Input.KEY_delete) then removeModEventListener(schemaPosition); end;
		end;
	end;--toggle help menu [press F1] to update position
end;
addModEventListener(schemaPosition);
--