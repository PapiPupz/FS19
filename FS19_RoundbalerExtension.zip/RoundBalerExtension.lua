--[[
	RoundBalerExtension.lua
	
	Autor: 		Ifko[nator]
	Datum: 		24.12.2018
	Version: 	1.0
	
	Changelog:	V 1.0 @ 24.12.2018 - initial implementation in FS 19
]]

RoundBalerExtension = {};
RoundBalerExtension.ACTIVATE_DEBUG = false;

function RoundBalerExtension.prerequisitesPresent(specializations)
	return true;
end;

function RoundBalerExtension.registerEventListeners(vehicleType)
	local functionNames = {
		"onLoad",
		"onUpdate",
	};
	
	for _, functionName in ipairs(functionNames) do
		SpecializationUtil.registerEventListener(vehicleType, functionName, RoundBalerExtension);
	end;
end;

function RoundBalerExtension:onLoad(savegame)
	local specRoundBalerExtension = self.spec_roundBalerExtension;
	
	specRoundBalerExtension.hasBaleUnloaded = false;
	specRoundBalerExtension.cruiseControlWasOn = false;
end;

function RoundBalerExtension:onUpdate(dt, isActiveForInput, isSelected)
	if self:getIsActive() then
		local specAttacherJoints = self.spec_attacherJoints;
		local specRoundBalerExtension = self.spec_roundBalerExtension;
	
		for _, implement in pairs(specAttacherJoints.attachedImplements) do
			if implement ~= nil and implement.object ~= nil then
				local roundBaler = implement.object;
				local controlledTractor = roundBaler:getAttacherVehicle();
				
				local specDrivable = controlledTractor.spec_drivable;
				local specBaler = roundBaler.spec_baler;
				local specWheelsTractor = controlledTractor.spec_wheels;
				local specWheelsRoundBaler = roundBaler.spec_wheels;
				
				local cruiseControlIsActive = 
					specDrivable.cruiseControl.state == Drivable.CRUISECONTROL_STATE_FULL 
				or 
					specDrivable.cruiseControl.state == Drivable.CRUISECONTROL_STATE_ACTIVE
				;
				
				if specBaler ~= nil and specBaler.firstBaleMarker == nil and roundBaler:getIsTurnedOn() then
					--## we have an round baler attached :)
					
					if RoundBalerExtension.ACTIVATE_DEBUG then
						renderText(0.5, 0.5, 0.02, "roundBaler.spec_fillUnit:getFillUnitFillLevel(1) = " .. roundBaler.spec_fillUnit:getFillUnitFillLevel(1));
						renderText(0.5, 0.48, 0.02, "roundBaler.spec_fillUnit:getFillUnitCapacity(1) = " .. roundBaler.spec_fillUnit:getFillUnitCapacity(1));
						renderText(0.5, 0.46, 0.02, "specBaler.unloadingState = " .. tostring(specBaler.unloadingState));
						renderText(0.5, 0.44, 0.02, "specDrivable.cruiseControl.state = " .. tostring(specDrivable.cruiseControl.state));
						renderText(0.5, 0.42, 0.02, "cruiseControlIsActive = " .. tostring(cruiseControlIsActive));
					end;
					
					if specRoundBalerExtension.hasBaleUnloaded then	
						controlledTractor:setBrakeLightsVisibility(true);
					end;
					
					if roundBaler.spec_fillUnit:getFillUnitFillLevel(1) == roundBaler.spec_fillUnit:getFillUnitCapacity(1) then
						if not specRoundBalerExtension.hasBaleUnloaded then
							specRoundBalerExtension.hasBaleUnloaded = true;
						end;
						
						if cruiseControlIsActive then
							controlledTractor:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF);
							
							specRoundBalerExtension.cruiseControlWasOn = true;
						end;
						
						if self.isServer then
							for _, wheel in pairs(specWheelsTractor.wheels) do
								setWheelShapeProps(wheel.node, wheel.wheelShape, 0, math.huge, 0, 0);
							end;
							
							for _, wheel in pairs(specWheelsRoundBaler.wheels) do
								setWheelShapeProps(wheel.node, wheel.wheelShape, 0, math.huge, 0, 0);
							end;
						end;
						
						if #specBaler.bales > 0 and specBaler:isUnloadingAllowed() then
							roundBaler:setIsUnloadingBale(true);
						end;
					elseif specBaler.unloadingState ~= Baler.UNLOADING_CLOSED then
						if specBaler.unloadingState == Baler.UNLOADING_OPEN then
							roundBaler:setIsUnloadingBale(false);
						end;
						
						if self.isServer then
							for _, wheel in pairs(specWheelsTractor.wheels) do
								setWheelShapeProps(wheel.node, wheel.wheelShape, 0, math.huge, 0, 0);
							end;
							
							for _, wheel in pairs(specWheelsRoundBaler.wheels) do
								setWheelShapeProps(wheel.node, wheel.wheelShape, 0, math.huge, 0, 0);
							end;
						end;
					elseif specBaler.unloadingState == Baler.UNLOADING_CLOSED then
						if specRoundBalerExtension.hasBaleUnloaded then
							if specRoundBalerExtension.cruiseControlWasOn then	
								controlledTractor:setCruiseControlState(Drivable.CRUISECONTROL_STATE_FULL);
								
								specRoundBalerExtension.cruiseControlWasOn = false;
							end;
							
							specRoundBalerExtension.hasBaleUnloaded = false;
						end;
					end;
				end;
			end;
		end;
	end;
end;