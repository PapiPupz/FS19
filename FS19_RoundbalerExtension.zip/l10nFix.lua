--[[
l10nFix

Author: 	Ifko[nator]
Date: 		19.12.2018
Version:	1.0

Usage:

instead of ' g_i18n:getText("Text") ' use ' Vehicle.Text ' in your global mod script file
]]

l10nFix = {};
l10nFix.modDirectory = g_currentModDirectory;

function l10nFix:loadMap(name)
	local modDesc = loadXMLFile("modDesc", l10nFix.modDirectory .. "modDesc.xml");
	local count = 0;
	
	while true do
		local baseText = string.format("modDesc.l10n.text(%d)", count);
		
		if not hasXMLProperty(modDesc, baseText) then
			break;
		end;
		
		local name = getXMLString(modDesc, baseText .. "#name");
		
		if name ~= nil then
			Vehicle[name] = g_i18n:getText(name);
		end;
		
		count = count + 1;
	end;
end;

--## unused but needed functions

function l10nFix:update(dt)end;
function l10nFix:deleteMap()end;
function l10nFix:keyEvent(unicode, sym, modifier, isDown)end;
function l10nFix:mouseEvent(posX, posY, isDown, isUp, button)end;
function l10nFix:draw()end;

addModEventListener(l10nFix);