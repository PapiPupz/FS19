-- Register functionality by: Ian898 
-- Date: 26/11/2018
-- THANK YOU IAN!

-- "by" modelleicher
-- used to remove locked steering axle when front loaders are attached


g_specializationManager:addSpecialization("frontloaderAxleLockRemover", "frontloaderAxleLockRemover", g_currentModDirectory.."frontloaderAxleLockRemover.lua")

registerFrontloaderAxleLockRemover = {}

function registerFrontloaderAxleLockRemover:register(name)
    
    for _, vehicle in pairs(g_vehicleTypeManager:getVehicleTypes()) do
        
        local frontloaderAttacher = false;
        local frontloaderAxleLockRemover = false;
        
        for _, spec in pairs(vehicle.specializationNames) do
        
            if spec == "frontloaderAttacher" then -- check for frontloaderAttacher, only insert into frontloaderAttacher
                frontloaderAttacher = true;
            end
            
            if spec == "frontloaderAxleLockRemover" then -- don't insert if already inserted
                frontloaderAxleLockRemover = true;
            end
            
        end    
        if frontloaderAttacher and not frontloaderAxleLockRemover then
            g_vehicleTypeManager:addSpecialization(vehicle.name, "FS19_frontloaderAxleLockRemover.frontloaderAxleLockRemover")
        end
    end
    
end

VehicleTypeManager.finalizeVehicleTypes = Utils.prependedFunction(VehicleTypeManager.finalizeVehicleTypes, registerFrontloaderAxleLockRemover.register)