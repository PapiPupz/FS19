﻿----------------------------------------------------------------------------
----Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------

reAssignCategories = {};
reAssignCategories.tools = {"aquatrans", "mks", "fst 990"};
reAssignCategories.stations = {g_i18n:getText("shopItem_waterTower"), g_i18n:getText("shopItem_limeStation")}; --these specific l10n values are always available

function reAssignCategories:addNewCategories()
	g_storeManager:addCategory("liquidtransport", g_i18n:getText("cat_LiquidTransport"), "data/vehicles/joskin/joskinAquaTrans7300/store_joskinAquaTrans7300.dds", "TOOL", "");
	g_storeManager:addCategory("refillstations", g_i18n:getText("cat_RefillStations"), "data/placeables/waterTank/store_waterTank.dds", "PLACEABLE", "");
end;

function reAssignCategories:loadMap(savegame)

	local storeItems = g_storeManager:getItems();

	for _, item in pairs(storeItems) do
		-- tools
		for _, tool in pairs(reAssignCategories.tools) do
			if string.find(string.lower(item.name), tool) then
				item.categoryName = "LIQUIDTRANSPORT";
			end;
		end;
		-- placeables
		for _, station in pairs(reAssignCategories.stations) do 
			if item.customEnvironment ~= nil and (string.lower(item.customEnvironment) == string.lower("FS19_placeableRefillStation")) then				
				item.categoryName = "REFILLSTATIONS";
			end;
			if string.lower(item.name) == string.lower(tostring(station)) then
				item.categoryName = "REFILLSTATIONS";
			end;
		end;
		
	end;

	--removeModEventListener(reAssignCategories);

end;

addModEventListener(reAssignCategories);