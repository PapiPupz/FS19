﻿----------------------------------------------------------------------------
----Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------

--[[modDesc example: 

  <addCategory>
  	<category name="xmlCategoryName" title="Ingame Title" type="2" imageFilename="images/category.dds"/>     <!-- TYPES: 1=VEHICLE 2=TOOL 3=OBJECT 4=PLACEABLE-->
  </addCategory> 

]]

CategoryAdder = {}
CategoryAdder.dir = g_currentModDirectory;
CategoryAdder.types = {"VEHICLE","TOOL","OBJECT","PLACEABLE"};
local modDescFile = loadXMLFile("modDesc", g_currentModDirectory .. "modDesc.xml");
CategoryAdder.title = getXMLString(modDescFile, "modDesc.title.en");
CategoryAdder.author = getXMLString(modDescFile, "modDesc.author");
CategoryAdder.version = getXMLString(modDescFile, "modDesc.version");
delete(modDescFile);
source(CategoryAdder.dir.."reAssignCategories.lua");

StoreManager.loadMapData = function (self, xmlFile, missionInfo, baseDirectory)
    StoreManager:superClass().loadMapData(self)
    local categoryXMLFile = loadXMLFile("storeCategoriesXML", "dataS/storeCategories.xml");
    local i = 0;
    while true do
        local baseXMLName = string.format("categories.category(%d)", i);
        if not hasXMLProperty(categoryXMLFile, baseXMLName) then
            break;
        end;
        local name = getXMLString(categoryXMLFile, baseXMLName .. "#name");
        local title = getXMLString(categoryXMLFile, baseXMLName .. "#title");
        local imageFilename = getXMLString(categoryXMLFile, baseXMLName .. "#image");
        local type = getXMLString(categoryXMLFile, baseXMLName .. "#type");
        if title ~= nil and title:sub(1, 6) == "$l10n_" then
            title = g_i18n:getText(title:sub(7));
        end;
        self:addCategory(name, title, imageFilename, type, "");
        i = i + 1;
    end
    delete(categoryXMLFile);
	---------------------------------------------------------------------------------------------------------------------------
	reAssignCategories:addNewCategories()  --Beginning of Mod
    for _, item in ipairs(self.modStoreItems) do
        g_deferredLoadingManager:addSubtask(function()
			if fileExists(item.baseDir.."modDesc.xml") then
				local modFile = loadXMLFile("descFile", item.baseDir.."modDesc.xml");
				if hasXMLProperty(modFile, "modDesc.addCategory") then
					local i = 0;
					while true do --Start Loop
						local configKey = string.format("modDesc.addCategory.category(%d)", i);
						if not hasXMLProperty(modFile, configKey) then break; end; -- End Loop when none are left.
						local requirementsMet = 0;
						local name = getXMLString(modFile, configKey.."#name"); -- Category name to be called by XML
						if name ~= nil then	requirementsMet = requirementsMet + 1;
						else print("Error loading category name from "..item.customEnvironment); end;
						local title = getXMLString(modFile, configKey.."#title"); --l10n description (in game translatable Title)
						if title ~= nil then requirementsMet = requirementsMet + 1;
						else print("Error loading category title from "..item.customEnvironment); end;
						if title ~= nil and title:sub(1, 6) == "$l10n_" then title = g_i18n:getText(title:sub(7)); end;
						local type = getXMLInt(modFile, configKey.."#type");
						if type ~= nil then requirementsMet = requirementsMet + 1;
						else print("Error loading category type from "..item.customEnvironment); end;
						if type < 1 or type > 4 then type = CategoryAdder.types[2]; end;
						local imageFilename = getXMLString(modFile, configKey.."#imageFilename");
						if imageFilename ~= nil then requirementsMet = requirementsMet + 1;
						else print("Error loading category type from "..item.customEnvironment); end;
						if requirementsMet >= 4 then
							local image = 0
							if imageFilename == nil then
								image = CategoryAdder.dir.."icon.dds"; -- This Mod's Icon if nil.
								print("Error loading image from "..item.customEnvironment.."... Setting to default.");
							else
								image = item.baseDir..imageFilename; -- Specified New Category Image.
							end;
							self:addCategory(name, title, image, CategoryAdder.types[type], ""); -- Add new category.
						end;
						requirementsMet = 0;
						--print("Category: "..title.." registered");
						i = i + 1;
					end;
				end;
			end;
        end)
    end;--End of Mod
	---------------------------------------------------------------------------------------------------------------------------
    -- now load all storeitems
    local storeItemsFilename = "dataS/storeItems.xml";
    if g_isPresentationVersionSpecialStore then
        storeItemsFilename = g_isPresentationVersionSpecialStorePath;
    end;
    self:loadItemsFromXML(storeItemsFilename);
    if xmlFile ~= nil then
        local mapStoreItemsFilename = getXMLString(xmlFile, "map.storeItems#filename");
        if mapStoreItemsFilename ~= nil then
            mapStoreItemsFilename = Utils.getFilename(mapStoreItemsFilename, baseDirectory);
            self:loadItemsFromXML(mapStoreItemsFilename);
        end;
    end;

    for _, item in ipairs(self.modStoreItems) do
        g_deferredLoadingManager:addSubtask(function()
            self:loadItem(item.xmlFilename, item.baseDir, item.customEnvironment, item.isMod, item.isBundleItem, item.dlcTitle)
        end)
    end;

    return true;
end;

print("Load mod: "..CategoryAdder.title.." : v"..CategoryAdder.version.." by "..CategoryAdder.author);