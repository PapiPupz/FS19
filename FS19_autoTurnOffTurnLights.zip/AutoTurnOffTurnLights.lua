--[[
	AutoTurnOffTurnLights.lua
	
	Author: 	Ifko[nator]
	Date:		30.11.2018
	Version:	2.0 
	
	Changelog:	Version 1.0 @ 31.10.2016 - intial implementation in FS 17 
				Version 2.0 @ 30.11.2018 - convert and intial implementation in FS 19
]]


AutoTurnOffTurnLights = {};

function AutoTurnOffTurnLights:onLoad(savegame)
	self.spec_drivable.hasSteerToTurnLeftDirection = false;
	self.spec_drivable.hasSteerToTurnRightDirection = false;
end;

function AutoTurnOffTurnLights:onUpdate(dt)
	if self:getIsActive() and self.spec_drivable ~= nil and self.spec_drivable.steeringWheel ~= nil then
		local _, steeringRotY, _ = getRotation(self.spec_drivable.steeringWheel.node);
		
		if self.spec_drivable.hasSteerToTurnLeftDirection or self.spec_drivable.hasSteerToTurnRightDirection then
			local allowAutoTurnOffTurnLights = false;
			
			if self.spec_drivable.hasSteerToTurnLeftDirection then
				allowAutoTurnOffTurnLights = steeringRotY <= 0.001;
			elseif self.spec_drivable.hasSteerToTurnRightDirection then
				allowAutoTurnOffTurnLights = steeringRotY >= -0.001;
			end;
			
			if allowAutoTurnOffTurnLights then
				self:setTurnLightState(Lights.TURNLIGHT_OFF);
				
				self.spec_drivable.hasSteerToTurnLeftDirection = false;
				self.spec_drivable.hasSteerToTurnRightDirection = false;
			end;
		elseif self.spec_lights.turnLightState == Lights.TURNLIGHT_LEFT then
			self.spec_drivable.hasSteerToTurnLeftDirection = steeringRotY > 0.1;
		elseif self.spec_lights.turnLightState == Lights.TURNLIGHT_RIGHT then
			self.spec_drivable.hasSteerToTurnRightDirection = steeringRotY < -0.1;
		end;
	end;
end;

function AutoTurnOffTurnLights:loadMap(name)
	Drivable.onLoad = Utils.prependedFunction(Drivable.onLoad, AutoTurnOffTurnLights.onLoad);
	Drivable.onUpdate = Utils.prependedFunction(Drivable.onUpdate, AutoTurnOffTurnLights.onUpdate);
end;

function AutoTurnOffTurnLights:deleteMap()end;
function AutoTurnOffTurnLights:keyEvent(unicode, sym, modifier, isDown)end;
function AutoTurnOffTurnLights:mouseEvent(posX, posY, isDown, isUp, button)end;
function AutoTurnOffTurnLights:update(dt)end;
function AutoTurnOffTurnLights:draw()end;

addModEventListener(AutoTurnOffTurnLights);