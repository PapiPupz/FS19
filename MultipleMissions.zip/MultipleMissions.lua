-- MultipleMissions enables multiple work contracts in FS19

MultipleMissions = {}; 

function MultipleMissions:loadMap(name)
	MissionManager.hasFarmActiveMission = Utils.overwrittenFunction(MissionManager.hasFarmActiveMission, MultipleMissions.hasFarmActiveMission);
end; 

function MultipleMissions:hasFarmActiveMission(superFunc, ...)
    return false;
end

addModEventListener(MultipleMissions);