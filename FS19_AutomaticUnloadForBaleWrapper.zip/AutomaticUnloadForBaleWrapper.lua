--[[
	AutomaticUnloadForBaleWrapper.lua
	
	Autor: 		Ifko[nator]
	Datum: 		25.12.2018
	Version: 	1.0
	
	Changelog:	V 1.0 @ 25.12.2018 - initial implementation in FS 19
]]

AutomaticUnloadForBaleWrapper = {};
AutomaticUnloadForBaleWrapper.DROP_MODE_MANUAL = 1;
AutomaticUnloadForBaleWrapper.DROP_MODE_AUTOMATIC = 2;
AutomaticUnloadForBaleWrapper.DROP_MODE_COLLECT = 3;
AutomaticUnloadForBaleWrapper.DROP_MODE_MAX_STATE = 3;
AutomaticUnloadForBaleWrapper.FORCE_DROP_BALE = false;

function AutomaticUnloadForBaleWrapper.prerequisitesPresent(specializations)
	return true;
end;

function AutomaticUnloadForBaleWrapper.registerEventListeners(vehicleType)
	local functionNames = {
		"onLoad",
		"onUpdate",
		"saveToXMLFile",
		"onWriteStream",
		"onReadStream",
		"onRegisterActionEvents"
	};
	
	for _, functionName in ipairs(functionNames) do
		SpecializationUtil.registerEventListener(vehicleType, functionName, AutomaticUnloadForBaleWrapper);
	end;
end;

function AutomaticUnloadForBaleWrapper.registerFunctions(vehicleType)
	local functionNames = {
		"setDropMode",
		"toggleBaleWrapper"
	};
	
	for _, functionName in ipairs(functionNames) do
		SpecializationUtil.registerFunction(vehicleType, functionName, AutomaticUnloadForBaleWrapper[functionName]);
	end;
end;

function AutomaticUnloadForBaleWrapper:onLoad(savegame)
	local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
	local specBaler = self.spec_baler;
	
	if savegame ~= nil then
		specAutomaticUnloadForBaleWrapper.currentDropModeState = Utils.getNoNil(getXMLInt(savegame.xmlFile, savegame.key .. ".automaticUnloadForBaleWrapper#currentDropModeState"), AutomaticUnloadForBaleWrapper.DROP_MODE_MANUAL);
		
		if specBaler ~= nil then	
			specAutomaticUnloadForBaleWrapper.baleWrapperIsActive = Utils.getNoNil(getXMLBool(savegame.xmlFile, savegame.key .. ".automaticUnloadForBaleWrapper#baleWrapperIsActive"), true);
		end;
	else
		specAutomaticUnloadForBaleWrapper.currentDropModeState = AutomaticUnloadForBaleWrapper.DROP_MODE_MANUAL;
		
		if specBaler ~= nil then
			specAutomaticUnloadForBaleWrapper.baleWrapperIsActive = true;
		end;
	end;
	
	self:setDropMode(specAutomaticUnloadForBaleWrapper.currentDropModeState, false);
	
	if specBaler ~= nil then
		self:toggleBaleWrapper(specAutomaticUnloadForBaleWrapper.baleWrapperIsActive);
		
		self.doStateChange = Utils.overwrittenFunction(self.doStateChange, AutomaticUnloadForBaleWrapper.doStateChange);
		self.pickupWrapperBale = Utils.overwrittenFunction(self.pickupWrapperBale, AutomaticUnloadForBaleWrapper.pickupWrapperBale);
	end;
end;

function AutomaticUnloadForBaleWrapper:setDropMode(currentDropModeState, noEventSend)
    local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;

	if currentDropModeState ~= specAutomaticUnloadForBaleWrapper.currentDropModeState then
		specAutomaticUnloadForBaleWrapper.currentDropModeState = currentDropModeState;
		
		 if not noEventSend then
			if g_server ~= nil then
				g_server:broadcastEvent(SetDropModeEvent:new(self, currentDropModeState), nil, nil, self);
			else
				g_client:getServerConnection():sendEvent(SetDropModeEvent:new(self, currentDropModeState));
			end;
		end;
	end;
end;

function AutomaticUnloadForBaleWrapper:onWriteStream(streamId, connection)
	if not connection:getIsServer() then 
		local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
		local specBaler = self.spec_baler;
		
		streamWriteUIntN(streamId, specAutomaticUnloadForBaleWrapper.currentDropModeState, AutomaticUnloadForBaleWrapper.DROP_MODE_MAX_STATE);

		if specBaler ~= nil then	
			streamWriteBool(streamId, specAutomaticUnloadForBaleWrapper.baleWrapperIsActive);
		end;
	end;
end;

function AutomaticUnloadForBaleWrapper:onReadStream(streamId, connection)
	if connection:getIsServer() then
		local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
		local specBaler = self.spec_baler;
		
		specAutomaticUnloadForBaleWrapper.currentDropModeState = streamReadUIntN(streamId, AutomaticUnloadForBaleWrapper.DROP_MODE_MAX_STATE);
		
		if specBaler ~= nil then
			specAutomaticUnloadForBaleWrapper.baleWrapperIsActive = streamReadBool(streamId);
		end;
	end;
end;

function AutomaticUnloadForBaleWrapper:onRegisterActionEvents(isActiveForInput)
	if self.isClient then
        local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
        
		self:clearActionEventsTable(specAutomaticUnloadForBaleWrapper.actionEvents);
        
		if self:getIsActiveForInput(true) then
            local newFunctions = {
				"CHANGE_DROP_MODE_BUTTON",
				"TOGGLE_BALE_WRAPPER_BUTTON"
			};
			
			for _, newFunction in ipairs(newFunctions) do
				local _, actionEventId = self:addActionEvent(specAutomaticUnloadForBaleWrapper.actionEvents, InputAction[newFunction], self, AutomaticUnloadForBaleWrapper.actionEventChangeDropeMode, false, true, false, true, nil);
			
				g_inputBinding:setActionEventTextPriority(actionEventId, GS_PRIO_NORMAL);
				g_inputBinding:setActionEventTextVisibility(actionEventId, true);
				g_inputBinding:setActionEventActive(actionEventId, false);
			end;
		end;
	end;
end;

function AutomaticUnloadForBaleWrapper.actionEventChangeDropeMode(self, actionName, inputValue, callbackState, isAnalog)
	local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
	local specBaler = self.spec_baler;
	
	if actionName == "CHANGE_DROP_MODE_BUTTON" then
		if specAutomaticUnloadForBaleWrapper.currentDropModeState < AutomaticUnloadForBaleWrapper.DROP_MODE_MAX_STATE then
			self:setDropMode(specAutomaticUnloadForBaleWrapper.currentDropModeState + 1);
		else
			self:setDropMode(AutomaticUnloadForBaleWrapper.DROP_MODE_MANUAL);
		end;
	else
		if specBaler ~= nil then	
			self:toggleBaleWrapper(not specAutomaticUnloadForBaleWrapper.baleWrapperIsActive);
		end;
	end;
end;

function AutomaticUnloadForBaleWrapper:doStateChange(superFunc, id, nearestBaleServerId)
    local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
	local specBaleWrapper = self.spec_baleWrapper;
	
	if id == BaleWrapper.CHANGE_WRAPPING_START and not specAutomaticUnloadForBaleWrapper.baleWrapperIsActive then
        specBaleWrapper.baleWrapperState = BaleWrapper.STATE_WRAPPER_FINSIHED;
        
		return;
    end;
	
	superFunc(self, id, nearestBaleServerId);
end;

function AutomaticUnloadForBaleWrapper:pickupWrapperBale(superFunc, bale, baleType)
    local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
	
	if not specAutomaticUnloadForBaleWrapper.baleWrapperIsActive then 
        g_server:broadcastEvent(BaleWrapperStateEvent:new(self, BaleWrapper.CHANGE_GRAB_BALE, NetworkUtil.getObjectId(bale)), true, nil, self);
    else
        superFunc(self, bale, baleType);
    end;
end;

function AutomaticUnloadForBaleWrapper:toggleBaleWrapper(baleWrapperIsActive, noEventSend)
	local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
	
	if baleWrapperIsActive ~= specAutomaticUnloadForBaleWrapper.baleWrapperIsActive then
		if not noEventSend then
			if g_server ~= nil then
				g_server:broadcastEvent(ToggleBaleWrapperEvent:new(self, baleWrapperIsActive), nil, nil, self);
			else
				g_client:getServerConnection():sendEvent(ToggleBaleWrapperEvent:new(self, baleWrapperIsActive));
			end;
		end;
		
		specAutomaticUnloadForBaleWrapper.baleWrapperIsActive = baleWrapperIsActive;
	end;
end;

function AutomaticUnloadForBaleWrapper:saveToXMLFile(xmlFile, key)
	local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
	local specBaler = self.spec_baler;
	
	setXMLInt(xmlFile, key .. "#currentDropModeState", specAutomaticUnloadForBaleWrapper.currentDropModeState);
	
	if specBaler ~= nil then	
		setXMLBool(xmlFile, key .. "#balerWrapperIsActive", specAutomaticUnloadForBaleWrapper.baleWrapperIsActive);
	end;
end;

function AutomaticUnloadForBaleWrapper:onUpdate(dt, isActiveForInput, isSelected)
	if self:getIsActive() then
		local specAutomaticUnloadForBaleWrapper = self.spec_automaticUnloadForBaleWrapper;
		local specBaleWrapper = self.spec_baleWrapper;
		local specBaler = self.spec_baler;
		
		if specBaler == nil then
			--## disable the collect mode for single bale wrappers
			AutomaticUnloadForBaleWrapper.DROP_MODE_MAX_STATE = 2;
		else
			AutomaticUnloadForBaleWrapper.DROP_MODE_MAX_STATE = 3;
			
			if specBaleWrapper.baleToLoad == nil then
				if specBaleWrapper.baleWrapperState < BaleWrapper.STATE_MOVING_BALE_TO_WRAPPER or specBaleWrapper.baleWrapperState >= BaleWrapper.STATE_WRAPPER_WRAPPING_BALE then
					if specAutomaticUnloadForBaleWrapper.baleWrapperIsActive and self.isServer then
						local bale = NetworkUtil.getObject(specBaleWrapper.currentWrapper.currentBale);
						
						if bale ~= nil and bale.wrappingState == 0 and specBaleWrapper.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED then
							self:playMoveToWrapper(bale);
						end;
					end;
				end;
			end;
			
			local toggleBaleWrapperButton = specAutomaticUnloadForBaleWrapper.actionEvents[InputAction.TOGGLE_BALE_WRAPPER_BUTTON];
			
			if toggleBaleWrapperButton ~= nil then
				local currentText = Vehicle.START_BALE_WRAPPER;
				
				if specAutomaticUnloadForBaleWrapper.baleWrapperIsActive then
					currentText = Vehicle.STOP_BALE_WRAPPER;
				end;
				
				g_inputBinding:setActionEventActive(toggleBaleWrapperButton.actionEventId, true);
				g_inputBinding:setActionEventText(toggleBaleWrapperButton.actionEventId, currentText);
			end;
		end;
		
		local changeDropModeButton = specAutomaticUnloadForBaleWrapper.actionEvents[InputAction.CHANGE_DROP_MODE_BUTTON];
		
		if changeDropModeButton ~= nil then
			local currentText = Vehicle.DROP_MODE_MANUALLY;
			
			g_inputBinding:setActionEventActive(changeDropModeButton.actionEventId, true);
			
			if specAutomaticUnloadForBaleWrapper.currentDropModeState == AutomaticUnloadForBaleWrapper.DROP_MODE_AUTOMATIC then
				currentText = Vehicle.DROP_MODE_AUTOMATIC;
			elseif specAutomaticUnloadForBaleWrapper.currentDropModeState == AutomaticUnloadForBaleWrapper.DROP_MODE_COLLECT then
				currentText = Vehicle.DROP_MODE_COLLECT;
			end;
			
			g_inputBinding:setActionEventText(changeDropModeButton.actionEventId, string.gsub(Vehicle.CURRENT_DROP_MODE, "currentDropMode", currentText));
		end;
		
		if specBaleWrapper.baleWrapperState == BaleWrapper.STATE_WRAPPER_FINSIHED and specAutomaticUnloadForBaleWrapper.currentDropModeState > AutomaticUnloadForBaleWrapper.DROP_MODE_MANUAL then
			local allowDropBale = false;
			
			if specAutomaticUnloadForBaleWrapper.currentDropModeState == AutomaticUnloadForBaleWrapper.DROP_MODE_AUTOMATIC then
				allowDropBale = true;
			elseif AutomaticUnloadForBaleWrapper.FORCE_DROP_BALE then
				allowDropBale = true;
				
				AutomaticUnloadForBaleWrapper.FORCE_DROP_BALE = false;
			elseif specAutomaticUnloadForBaleWrapper.currentDropModeState == AutomaticUnloadForBaleWrapper.DROP_MODE_COLLECT then
				if self.spec_fillUnit:getFillUnitFillLevel(1) == self.spec_fillUnit:getFillUnitCapacity(1) then
					allowDropBale = true;
					
					AutomaticUnloadForBaleWrapper.FORCE_DROP_BALE = true;
				end;
			end;
			
			if self.isClient and allowDropBale then
				g_client:getServerConnection():sendEvent(BaleWrapperStateEvent:new(self, BaleWrapper.CHANGE_BUTTON_EMPTY));
			end;
		end;
	end;
end;

SetDropModeEvent = {};
SetDropModeEvent_mt = Class(SetDropModeEvent, Event);
InitEventClass(SetDropModeEvent, "SetDropModeEvent");

function SetDropModeEvent:emptyNew()
    local self = Event:new(SetDropModeEvent_mt);
    self.className = "SetDropModeEvent";
    return self;
end;

function SetDropModeEvent:new(baleWrapper, currentDropModeState)
    local self = SetDropModeEvent:emptyNew();
	
    self.baleWrapper = baleWrapper;
    self.currentDropModeState = currentDropModeState;
    
	return self;
end;

function SetDropModeEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.baleWrapper);
    streamWriteInt32(streamId, self.currentDropModeState);
end;

function SetDropModeEvent:readStream(streamId, connection)
    self.baleWrapper = NetworkUtil.readNodeObject(streamId);
    self.currentDropModeState = streamReadInt32(streamId);

    self:run(connection);
end;

function SetDropModeEvent:run(connection)	
	if not connection:getIsServer() then
		g_server:broadcastEvent(SetDropModeEvent:new(self.baleWrapper, self.currentDropModeState), nil, connection, self.baleWrapper);
	end;
	
	if self.baleWrapper ~= nil then	
		self.baleWrapper:setDropMode(self.currentDropModeState, true);
	end;
end;

ToggleBaleWrapperEvent = {};
ToggleBaleWrapperEvent_mt = Class(ToggleBaleWrapperEvent, Event);

InitEventClass(ToggleBaleWrapperEvent, "ToggleBaleWrapperEvent");

function ToggleBaleWrapperEvent:emptyNew()
	local self = Event:new(ToggleBaleWrapperEvent_mt);
    
	return self;
end;

function ToggleBaleWrapperEvent:new(baleWrapper, baleWrapperIsActive)
	local self = ToggleBaleWrapperEvent:emptyNew();
	
	self.baleWrapper = baleWrapper;
	self.baleWrapperIsActive = baleWrapperIsActive;
	
	return self;
end;

function ToggleBaleWrapperEvent:readStream(streamId, connection)
	self.baleWrapper = NetworkUtil.readNodeObject(streamId);
	self.baleWrapperIsActive = streamReadBool(streamId);
    
	self:run(connection);
end;

function ToggleBaleWrapperEvent:writeStream(streamId, connection)
	NetworkUtil.writeNodeObject(streamId, self.baleWrapper);
	streamWriteBool(streamId, self.baleWrapperIsActive);
end;

function ToggleBaleWrapperEvent:run(connection)
	if not connection:getIsServer() then
		g_server:broadcastEvent(ToggleBaleWrapperEvent:new(self.baleWrapper, self.baleWrapperIsActive), nil, connection, self.baleWrapper);
	end;
	
    if self.baleWrapper ~= nil then
        self.baleWrapper:toggleBaleWrapper(self.baleWrapperIsActive, true);
	end;
end;